

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AssignTAs
 */
@WebServlet("/AssignTAs")
public class AssignTAs extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignTAs() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String semester = request.getParameter("semester");
		String year = request.getParameter("year");
	    String course_id = request.getParameter("course_id");
	    String test_id = request.getParameter("test_id");
	    String ta = request.getParameter("ta_roll");
	    Integer index = Integer.parseInt(request.getParameter("index"));
	    
	    String query = "UPDATE ans set grader = ? where course_id = ? and semester = ? and year = ? and test_id = ? and index = ?";
	    
	    System.out.println("ta is gonna be assigned);" + index.toString());
	    
	    DbHelper.executeUpdateJson(
	    		query, 
	    		new DbHelper.ParamType[] {
	    				DbHelper.ParamType.STRING,
	    				DbHelper.ParamType.STRING,
	    				DbHelper.ParamType.STRING, 
	    				DbHelper.ParamType.STRING,
	    				DbHelper.ParamType.STRING,
	    				DbHelper.ParamType.INT,
	    		}, 
	    		new Object[] {ta, course_id, semester, year, test_id, index}
	    );
	    
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
