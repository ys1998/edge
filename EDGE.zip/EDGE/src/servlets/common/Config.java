package servlets.common;

/**
 * Edit to provide your database credentials
 */
public class Config {
	public static final String url = "jdbc:postgresql://localhost:5250/postgres";
	public static final String user = "naman";
	public static final String password = "";
}
